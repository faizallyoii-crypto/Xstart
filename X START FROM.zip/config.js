module.exports = {
  BOT_TOKEN:
  "8158346464:AAGSlODUHmq_-K1zn5g2UaqKMIbX830rHm4",
};